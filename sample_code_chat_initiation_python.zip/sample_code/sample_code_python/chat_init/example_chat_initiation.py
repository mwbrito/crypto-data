"""
Copyright 2020 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

Example code to post a message to specific recipients and a persistent chat containing a text message, a security table and a security pricing request.
"""

from http_client import post


def make_payload():
    payload = {
        "sender": {"uuid": 3344334},
        "recipients": [{"uuid": 9008001}, {"roomId": "PCHAT-0x0x0000001234567"}, {"uuid": 776543}],
        "chatMessage": {"text": "Hello World"},
        "table": {
            "json": {
                "rows": [
                    {
                        "isHeaderRow": True,
                        "cells": [
                            {"cell": [{"text": "Ticker"}], "halign": "Center"},
                            {"cell": [{"text": "Company"}], "halign": "Right"},
                            {"cell": [{"text": "Price"}], "halign": "Center"},
                        ],
                    },
                    {
                        "cells": [
                            {
                                "cell": [
                                    {
                                        "text": "ORA FP Equity",
                                        "style": {
                                            "decorations": [
                                                "Bold",
                                                "Italic",
                                            ]
                                        },
                                    }
                                ]
                            },
                            {
                                "cell": [{"text": "Orange SA"}],
                            },
                            {
                                "cell": [{"text": "10.18"}],
                            },
                        ]
                    },
                    {
                        "cells": [
                            {
                                "cell": [
                                    {
                                        "text": "VOD LN Equity",
                                        "style": {"decorations": ["Underline"]},
                                    }
                                ]
                            },
                            {
                                "cell": [{"text": "Vodafone Group PLC"}],
                            },
                            {
                                "cell": [{"text": "75.34"}],
                            },
                        ]
                    },
                    {
                        "cells": [
                            {
                                "cell": [
                                    {
                                        "text": "OMV AV Equity",
                                        "style": {"decorations": ["Strikethrough"]},
                                    }
                                ]
                            },
                            {
                                "cell": [{"text": "OMV AG"}],
                            },
                            {
                                "cell": [{"text": "40.23"}],
                            },
                        ]
                    },
                ]
            }
        },
        "structuredTemplate": [
            {
                "@type": "equity",
                "instrument": {
                    "bbid": "EK336104",
                    "cusip": "01748XAA",
                    "exchange": "IM",
                    "figi": "BBG008N18X67",
                    "ticker": "FCA",
                    "yellow_key": "Corp",
                },
                "quote": {
                    "ask_price": 198.45,
                    "bid_price": 101.32,
                    "if_natural": False,
                    "price": 198.45,
                },
                "intent": {"name": "Inquiry"},
                "side": {"side": "SELL"},
                "size": {"ask_size": 2000000, "bid_size": 2000000, "size": 7900},
            }
        ],
    }
    return payload


if __name__ == "__main__":
    path = "/ib/v1/initiateChat"
    payload = make_payload()
    try:
        post(path, payload)
    except Exception as e:
        print("exception received: {}".format(e))

    print(payload)
