"""
Copyright 2021 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

"""

import json

from http_client import get

if __name__ == "__main__":
    """
    IB REST API browser
    """
    print("request endpoint:")
    print("/ib/v1/documentation.json")
    print("you should get full json schema in return")
    print(json.loads(get("/ib/v1/documentation.json").text))
