"""
Copyright 2020 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

sample code to send Unsolicited Idea Drawer request.
Before execution, please check three things:
1. You have set IBAPI_CLIENT_ID and IBAPI_CLIENT_SECRET in your environment.
2. "recipients" defined in __main__ need to be the uuid of the recipient(s)
3. "destinations" defined in __main__ need to be a valid persistent chat room
    that all participants are enabled for the stream
4. other than the success reply you receive (see the file
   example_post_unsolicited_idea_output) you should see corresponding
   action on your Bloomberg screen.
   For the example  given in this file you will see following text
   in idea drawer:

   suggestion string 0
   suggestion string 1
   hola test
   I want to buy T 3 05/15/45
"""

from http_client import post


def generateStructuredUnsolicitedPostRequest(
    recipient: int, destination: str, additional_suggestions=2
):
    """
    Returns a structured unsolicited idea drawer post payload
    """
    request = {
        "@type": "UIDEA",
        "recipients": [{"uuid": recipient}],
        "destinations": {"roomIds": [{"roomId": destination}]},
        "suggestions": [
            {
                "text": "I want to buy",
                "structuredTemplate": [
                    {
                        "@type": "fixed_income_cash",
                        "instrument": {
                            "bbid": "EK336104",
                            "cusip": "01748XAA",
                            "figi": "BBG008N18X67",
                            "ticker": "FCA",
                            "yellow_key": "Corp",
                        },
                        "quote": {
                            "benchmark": "BBG008N18X67",
                            "benchmark_yellow_key": "Corp",
                            "settlement_currency": "EUR",
                            "settlement_date": "September",
                            "underlying_equity": {"price": 29.12, "ticker": "T"},
                            "values": [
                                {"ask_value": 30.11, "bid_value": 30.11, "value_type": "PRICE"}
                            ],
                        },
                    }
                ],
                "action": "VIEW_ONLY",
            }
        ],
    }
    for i in range(additional_suggestions):
        request["suggestions"].append({"text": "suggestion string {}".format(i)})
    return request


def postToStream(recipient: int, destination: str, streamId: str):
    print("Creating the request payload")
    payload = generateStructuredUnsolicitedPostRequest(recipient, destination)

    try:
        post_URL = "/ib/v1/streams/{}".format(streamId)
        post(post_URL, payload)
        print(f"Posted to {post_URL}.")
    except Exception as e:
        print(f"Caught exception: {e}")
        print(f"URL: {post_URL}")


if __name__ == "__main__":

    """
    Posting to stream
    """

    streamId = "idea-drawer-demo"
    recipient = 31062755
    destination = "PCHAT-0x1000004996847"
    postToStream(recipient, destination, streamId)
