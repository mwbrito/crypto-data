"""
Copyright 2020 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

sample code to send Idea Drawer request.
Before execution, please check three things:
1. You have set IBAPI_CLIENT_ID and IBAPI_CLIENT_SECRET in your environment.
2. "eventId" defined in __main__ need to be a valid eventId
3. max of 5 posts is allowed to the same eventId
4. other than the success reply you receive (see the file example_post_idea_output)
   you should see corresponding action on your Bloomberg screen.
   For the example  given in this file you will see following text
   in idea drawer:

   suggestion string 0
   suggestion string 1
   hola test
   I want to buy T 3 05/15/45
"""

from http_client import post


def generateStructuredIdeaPostRequest(eventId: str):
    """
    Returns a structured idea drawer post payload
    """
    return {
        "@type": "IDEA",
        "eventCorrelationId": eventId,
        "suggestions": [
            {
                "text": "I want to buy",
                "structuredTemplate": [
                    {
                        "@type": "fixed_income_cash",
                        "instrument": {
                            "bbid": "EK336104",
                            "cusip": "01748XAA",
                            "figi": "BBG008N18X67",
                            "ticker": "FCA",
                            "yellow_key": "Corp",
                        },
                        "quote": {
                            "benchmark": "BBG008N18X67",
                            "benchmark_yellow_key": "Corp",
                            "settlement_currency": "EUR",
                            "settlement_date": "September",
                            "underlying_equity": {"price": 29.12, "ticker": "T"},
                            "values": [
                                {"ask_value": 30.11, "bid_value": 30.11, "value_type": "PRICE"}
                            ],
                        },
                    }
                ],
                "action": "ORIGINAL_ROOM",
            }
        ],
    }


def generateIdeaPostRequest(eventId: str, number_of_suggestions=2):
    """
    Return a idea drawer post request that doesn't support structured payload

    Arg:
        number_of_suggestions: number of suggestions in the post request

    """

    request = {"@type": "IDEA", "eventCorrelationId": eventId, "suggestions": []}

    for i in range(number_of_suggestions):
        request["suggestions"].append({"text": "suggestion string {}".format(i)})
    return request


def postToStream(eventId: str, streamId: str, payloadType: int):
    if payloadType == 0:
        print("Sending text payload")
        payload = generateIdeaPostRequest(eventId)
    else:
        print("Sending structured payload")
        payload = generateStructuredIdeaPostRequest(eventId)

    try:
        post_URL = "/ib/v1/streams/{}".format(streamId)
        post(post_URL, payload)
        print(f"Posted to {post_URL}.")
    except Exception as e:
        print(f"Caught exception: {e}")
        print(f"URL: {post_URL}")


if __name__ == "__main__":

    """
    Posting to stream
    """

    streamId = "intel-drawer-demo"
    eventId = "16194446299470233602"
    # payloadType 0: text payload, 1: structured payload
    payloadType = 0
    postToStream(eventId, streamId, payloadType)
    payloadType = 1
    postToStream(eventId, streamId, payloadType)
