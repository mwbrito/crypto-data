"""
Copyright 2021 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

"""

import json
import random
import time

import requests
from http_client import endpoint, generate_url

"""
* During disconnection time, it is possible to miss some live-messages.
* You can mitigate that situation by reconnecting with the backfillId
  of your last ingested message.
* Your stream will resume with all subsequent events after that.
* BackfillId:
  * It expires after 5 mins.
  * If you reconnect with an expired backfillId, you will get an 410 Http Response (GONE).
  * If you reconnect with an invalid backfillId, you will get an 400 Http Response (BAD REQUEST).
"""

if __name__ == "__main__":
    """
    Reading the streamed data from IB
    """
    max_backoff_second = 2**4  # You can set it to any value that fits your workflow
    backoff_second = 1

    # BackfillId from a message within the last 5 mins
    # * The first time can be empty
    # * The second time you can use backfill printed in line 60
    backfill_id = None
    while True:
        try:
            path = "/ib/v1/streams/{stream_id}".format(stream_id="<YOUR-STREAM-ID>")
            uri_with_jwt = generate_url(endpoint, path, "GET") + (
                f"&backfillId={backfill_id}" if backfill_id else ""
        )

            response = requests.get(uri_with_jwt, stream=True)
            response.raise_for_status()

            print("Start listening to the stream...")
            backoff_second = 1  # reset backoff time

            for line in response.iter_lines():
                message = json.loads(line)
                print(message)
                backfill_id = message.get(
                    "backfillId"
                )  # You can use it to make a backfill request
                print(f"{backfill_id=}\n")
        except Exception as e:
            if response.status_code == 503:
                print("Server temporarily unavailable (503). Retrying with same backfillId...")
            elif response.status_code in [410, 400]:
                print(f"{response.reason} ({response.status_code}) - detail={response.json()}")
                backfill_id = None
            else:
                print(f"Exception happened {e}")

        # Exponential backoff: the sleep time is capped by max_backoff_second
        sleep_time = backoff_second + random.uniform(0, 0.5)
        print(f"Trying again in {sleep_time} seconds...")
        time.sleep(sleep_time)
        backoff_second = min(backoff_second * 2, max_backoff_second)
