"""
Copyright 2021 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

"""
import json
import random
import time

from requests.exceptions import ChunkedEncodingError

from http_client import get

if __name__ == "__main__":
    """
    Reading the streamed data from IB
    """
    stream_id = "<YOUR_STREAM_ID>"
    max_backoff_second = 2**4  # You can set it to any value that fits your workflow
    backoff_second = 1
    while True:
        try:
            response = get(f"/ib/v1/streams/{stream_id}", stream=True)
            lines = response.iter_lines()

            print("Start listening to the stream...")
            backoff_second = 1  # reset backoff time

            for line in lines:
                print(json.loads(line))

        except ChunkedEncodingError as e:
            print(f"ChunkedEncodingError happened {e}")
        except Exception as e:
            print(f"Exception happened {e}")

        # Exponential backoff: the sleep time is capped by max_backoff_second
        sleep_time = backoff_second + random.uniform(0, 0.5)
        print(f"Trying again in {sleep_time} seconds...")
        time.sleep(sleep_time)
        backoff_second = min(backoff_second * 2, max_backoff_second)
