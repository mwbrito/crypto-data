# README

Copyright 2018 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.

## IB REST API Examples

Prior to running the examples, please make sure that you obtain your
`client_id` and `client_secret` credentials provided by Bloomberg. These credentials
will be used to authenticate with the Bloomberg Cloud Infrastructure.

# Quick Start

This example uses Python 3.12, but you can use any [supported Python version](https://devguide.python.org/versions/#supported-versions).

1. Under the `sample_code` directory, please navigate to the `sample_code_python` folder.

2. Create and activate a [virtual environment](https://docs.python.org/3/tutorial/venv.html).

3. Install the dependencies into the virtual environment

	```
	> python -m pip install requests "pyjwt>=2.3.0" "urllib3>=2.6.3"
	```

4. Set your credentials as environment variables before running the examples:

	```
	> export IBAPI_CLIENT_ID=your-client-id
	> export IBAPI_CLIENT_SECRET=your-client-secret
	```

   The examples read `IBAPI_CLIENT_ID` and `IBAPI_CLIENT_SECRET` from the environment and
   raise a clear error if either is missing. Keep your real credentials private;
   do not commit or share them.
5. Run an example

	```
	> python -m feed_ondemand.example_documentation
	```

# Example Output

Some examples here ship with a record of what to expect when you run them:

| File | Contents |
|---|---|
| `<example>_output` | Console output from a sample run |

<hr>


### example_documentation.py

This example returns full json schema for the requests.

### example_read_stream.py
It demonstrates how get the list of streams belongs to a firm and also how to listen to the stream data that is posted to a given stream ID.

### example_post_idea.py

This example sends an Idea Drawer response, but in addition to the ability to send a text formatted suggestions, it also sends suggestions in a structured data ("pill"). To run the service, a valid eventId (that the response responds to) need to be provided. You also have the option of sending the suggestions in the response in text or in structured data.

### example_streamlist.py
This example illustrates how to retrieve the list of streams enabled by the firm.
