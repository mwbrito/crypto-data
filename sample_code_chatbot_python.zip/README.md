# IB Connect API - Sample Code

This download contains sample code for the IB Connect API, along with
documentation on how to authenticate against it.

# Contents

### authentication_documentation
Contains information about how the IB Connect API does authentication of client endpoints and detailed information about JWT

### sample_code
Sample code exercising various API calls. A README sits alongside the samples
themselves, describing what each example does and how to run it.

### API documentation
Refer to our developer console at https://console.bloomberg.com (https://beta.console.bloomberg.com if you only have BETA access) for IB API schema documentation.
