"""
Copyright 2017 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

"""

from http_client import endpoint, generate_url, retryable


def get_rooms(path):
    uri_with_jwt = generate_url(endpoint, path, "GET")
    response = retryable.get(uri_with_jwt)
    if response.status_code not in range(200, 300):
        print("Response body: {}".format(response.text))
        raise Exception(
            "Get chatbot rooms returned error status: {} - {}".format(
                response.status_code, response.reason
            )
        )
    print("Received chatbot rooms response: {}".format(response.text))
