# IB REST API Chatbot Examples

Copyright 2018 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.

## Prerequisites

Obtain your `client_id` and `client_secret` credentials from Bloomberg. These are used to authenticate with the Bloomberg Cloud Infrastructure.

## Quick Start

This example uses Python 3.12, but you can use any [supported Python version](https://devguide.python.org/versions/#supported-versions).

1. Change into the `sample_code_python` directory. Every command in this README
   assumes it is your working directory.

    ```sh
    cd sample_code/sample_code_python
    ```

2. Create and activate a [virtual environment](https://docs.python.org/3/tutorial/venv.html).

3. Install the dependencies into the virtual environment:

    ```sh
    python -m pip install requests "pyjwt>=2.3.0" "urllib3>=2.6.3"
    ```

4. Set your credentials as environment variables before running the examples:

    ```sh
    export IBAPI_CLIENT_ID=your-client-id
    export IBAPI_CLIENT_SECRET=your-client-secret
    ```

   The examples read `IBAPI_CLIENT_ID` and `IBAPI_CLIENT_SECRET` from the environment and
   raise a clear error if either is missing. Keep your real credentials private;
   do not commit or share them.

5. Run an example

    ```sh
    python -m chatbot.example_documentation
    ```

## Example Output

The examples here ship with a record of what to expect when you run them:

| File | Contents |
|---|---|
| `<example>_output` | Console output from a sample run |
| `<example>_result.PNG` | Screenshot of the result in IB |

---

## example_documentation.py

Returns the full JSON schema for chatbot API requests. No configuration required.

```sh
python -m chatbot.example_documentation
```

---

## example_post_rich_messages.py

Demonstrates a chatbot that posts different types of messages. Pass the configuration as command-line flags (run with `--help` to see them):

| Flag | Type | Required | Description |
|---|---|---|---|
| `--chatbot-uuid` | integer | Yes | UUID of your chatbot |
| `--room-id` | string | Yes | ID of the room to post to. Press `Ctrl+Shift+R` on an IB room to find it (e.g. `"PCHAT-0x100000234567"`) |
| `--at-mention-uuid` | integer | No | UUID of the user to @mention. Defaults to a sample UUID |

```sh
python -m chatbot.example_post_rich_messages --chatbot-uuid 12345678 --room-id PCHAT-0x100000234567
```

---

## example_post_market_commentary_with_title_image.py

Demonstrates a chatbot that uploads an image file (`POST /ib/v1/files`) and posts a market commentary that uses the returned `fileReferenceId` as its title image (sent as `titleImage: {"fileReferenceId": ...}`). Pass the configuration as command-line flags (run with `--help` to see them):

| Flag | Type | Required | Description |
|---|---|---|---|
| `--chatbot-uuid` | integer | Yes | UUID of your chatbot |
| `--room-id` | string | Yes | ID of the room to post to. Press `Ctrl+Shift+R` on an IB room to find it (e.g. `"PCHAT-0x100000234567"`) |
| `--image-path` | string | No | Path to the title image, in JPG, JPEG, PNG, GIF, or WebP format. Defaults to a sample Bloomberg logo |

```sh
python -m chatbot.example_post_market_commentary_with_title_image --chatbot-uuid 12345678 --room-id PCHAT-0x100000234567
```

---

## example_listen_and_respond.py

Demonstrates a two-way chatbot that listens on a stream and responds when mentioned. Messages from rooms other than `--room-id` are dropped, so the bot only responds in the room you designate for testing. Pass the configuration as command-line flags (run with `--help` to see them):

| Flag | Type | Required | Description |
|---|---|---|---|
| `--chatbot-uuid` | integer | Yes | UUID of your chatbot |
| `--stream-id` | string | Yes | ID of the stream your chatbot subscribes to |
| `--room-id` | string | Yes | Room to limit listening to. Press `Ctrl+Shift+R` on an IB chat room to copy its ID (e.g. `"PCHAT-0x100000234567"`) |
| `--enable-reply-to` | flag | No | Present to use the `Reply-to` feature; omit to respond with a plain message |

```sh
python -m chatbot.example_listen_and_respond --chatbot-uuid 12345678 --stream-id a1b2c3d4 --room-id PCHAT-0x100000234567 --enable-reply-to
```
