"""
Copyright 2021 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.
"""

import argparse

from http_client import post
from .common import get_rooms

# Sample @mention target used when --at-mention-uuid is not supplied.
DEFAULT_AT_MENTION_UUID = 11098254


def create_link_and_mention_payload(chatbot_uuid, room_id, at_mention_uuid):
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {"contentType": "TEXT", "text": "This is a plaintext.\n"},
                    {
                        "contentType": "LINK",
                        "href": "https://github.com/",
                        "title": "This is an http link to visit GitHub",
                    },
                    {
                        "contentType": "TEXT",
                        "text": "\nHere is an example of an @mention of a user ",
                    },
                    {"contentType": "MENTION", "user": {"uuid": at_mention_uuid}},
                    {"contentType": "TEXT", "text": "\n"},
                ]
            }
        ],
    }


def create_table_payload(chatbot_uuid, room_id):
    table_element = {
        "contentType": "TABLE",
        "rows": [
            {
                "cells": [
                    {"cell": [{"text": "Table Example"}]},
                    {"cell": [{"text": "AAA"}]},
                    {"cell": [{"text": "BBB"}]},
                ],
                "isHeaderRow": True,
            },
            {
                "cells": [
                    {"cell": [{"text": "111"}]},
                    {"cell": [{"text": "222"}]},
                    {"cell": [{"text": "rowspan=2"}], "rowspan": 2},
                ]
            },
            {
                "cells": [
                    {"cell": [{"text": "333"}]},
                    {"cell": [{"text": "444"}]},
                ]
            },
            {
                "cells": [
                    {"cell": [{"text": "555"}]},
                    {"cell": [{"text": "colspan=2"}], "colspan": 2},
                ]
            },
        ],
    }
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {"contentType": "TEXT", "text": "This is a table:\n"},
                    table_element,
                ]
            }
        ],
    }


def create_market_commentary_payload(chatbot_uuid, room_id):
    market_commentary_element = {
        "contentType": "MARKET COMMENTARY",
        "title": "Out of the Box: Looking Out and Lookout",
        "body": {
            "blocks": [
                {
                    "type": "Paragraph",
                    "tokens": [
                        {
                            "type": "Text",
                            "text": "The ",
                            "attributes": {"strong": True},
                        },
                        {
                            "type": "Text",
                            "text": "markets currently are flummoxed, ",
                            "attributes": {"strong": True},
                        },
                        {
                            "type": "Text",
                            "text": "in my opinion, and caution is advised. When the height of the ",
                        },
                        {"type": "Text", "text": "Yield Curve"},
                        {"type": "Text", "text": " is the "},
                        {"type": "Text", "text": "8 month "},
                        {"type": "Text", "text": "6 month "},
                        {
                            "type": "Link",
                            "destination": {
                                "type": "BBLink",
                                "securities": ["IBM US Equity"],
                                "mnemonic": "VRS",
                                "tails": ["/G", "IB2-APPLICATION"],
                            },
                            "tokens": [
                                {
                                    "type": "Text",
                                    "text": "Treasury ",
                                    "attributes": {"em": True},
                                },
                                {
                                    "type": "Text",
                                    "text": "Bill",
                                    "attributes": {"em": True},
                                },
                            ],
                        },
                        {
                            "type": "Text",
                            "text": ", you know that we are nowhere close to normal. ",
                        },
                        {
                            "type": "Text",
                            "text": "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam nec velit purus. Donec lacinia purus vitae risus consequat, id gravida nibh pulvinar. Cras ut velit tincidunt, maximus tortor porta, dapibus urna. In hac habitasse platea dictumst. Donec dapibus diam egestas tincidunt lobortis. Suspendisse ut volutpat est. Mauris pellentesque ante eros, id pulvinar leo mollis in. Ut aliquam neque id risus elementum pellentesque. Vestibulum sit amet mi at purus egestas auctor ut quis nisi. Nulla risus felis, imperdiet at maximus eget, pulvinar eget dui.",
                        },
                    ],
                }
            ]
        },
        "metadata": {
            "instruments": [{"figi": "BBG000B9XRY4"}, {"figi": "BBG000N9MNX3"}]
        },
    }
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {"contentType": "TEXT", "text": "This is a market commentary:\n"},
                    market_commentary_element,
                ]
            }
        ],
    }


def create_order_update_payload(chatbot_uuid, room_id):
    order_update = {
        "contentType": "ORDER UPDATE",
        "body": {
            "side": "Sell",
            "size": 17999,
            "instrument": {"figi": "BBG000BDTBL9"},
            "orderType": "MKT",
            "orderStatus": "Rejected",
            "strategy": "VWAP",
            "timestamp": 1725354223000,
            "notes": "Close allocation 1 pct of 21 day avg close volume.",
            "client": "Bonsai Investment Mgmt",
            "broker": "Birch Creek Securities",
            "filledQuantity": 10750,
            "timeInForce": "FOK",
            "trader": "Jane Smith",
            "maxParticipationPercentage": "3%",
            "benchmark": "S&P 500",
            "account": "Account Name",
            "venue": "Venue Name",
            "totalMarketValue": 44999.9999,
            "averagePrice": 44999.9999,
            "targetPrice": 44999.9999,
        },
    }
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {"contentType": "TEXT", "text": "This is an order update:\n"},
                    order_update,
                ]
            }
        ],
    }


def create_suggested_response_payload(chatbot_uuid, room_id):
    # Suggested responses sit beside messageElements, not inside it, and render as a
    # row of buttons at the end of the message. Send 1 to 5 of them; each buttonText
    # is at most 30 characters and must be unique within the message. When a
    # recipient clicks a button, its text is posted as their reply, and your chatbot
    # receives it as an ordinary inbound message.
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {
                        "contentType": "TEXT",
                        "text": "Which name would you like today's research summary on?",
                    },
                ],
                "suggestedResponses": [
                    {"contentType": "CLICK TO REPLY", "buttonText": "NVDA"},
                    {"contentType": "CLICK TO REPLY", "buttonText": "TSLA"},
                    {"contentType": "CLICK TO REPLY", "buttonText": "AAPL"},
                ],
            }
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Post example chatbot messages to a room."
    )
    parser.add_argument(
        "--chatbot-uuid", type=int, required=True, help="UUID of your chatbot"
    )
    parser.add_argument(
        "--room-id",
        required=True,
        help='ID of the room to post to. Press Ctrl+Shift+R on an IB room to copy its ID '
        '(ex: "PCHAT-0x100000234567")',
    )
    parser.add_argument(
        "--at-mention-uuid",
        type=int,
        default=DEFAULT_AT_MENTION_UUID,
        help="UUID of the user to @mention (defaults to a sample UUID)",
    )
    args = parser.parse_args()

    post_path = "/ib/v1/chatbot"
    try:
        post(post_path, create_link_and_mention_payload(
            args.chatbot_uuid, args.room_id, args.at_mention_uuid
        ))
        post(post_path, create_table_payload(args.chatbot_uuid, args.room_id))
        post(post_path, create_market_commentary_payload(args.chatbot_uuid, args.room_id))
        post(post_path, create_order_update_payload(args.chatbot_uuid, args.room_id))
        post(post_path, create_suggested_response_payload(args.chatbot_uuid, args.room_id))
        get_rooms(path=f"{post_path}/{args.chatbot_uuid}/rooms")
    except Exception as e:
        print(f"Exception was thrown: {e=}")
