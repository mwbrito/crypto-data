"""
Copyright 2026 Bloomberg L.P. All rights reserved.
Use governed by applicable Bloomberg Terminal agreement.
"""

import argparse
import mimetypes
import os

from http_client import post, upload

# Generic image used as the title image when --image-path is not supplied.
DEFAULT_IMAGE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bloomberg_logo.jpg")


def upload_title_image(image_path):
    """
    Uploads an image file and returns its fileReferenceId, which can then be
    used as the titleImage of a market commentary.
    Supported formats: jpg, jpeg, png, gif, webp
    """
    # Read the file into memory, rather than passing an open file, so the
    # request body can be resent if the upload is retried
    with open(image_path, "rb") as image_file:
        image_data = image_file.read()
    mime_type = mimetypes.guess_type(image_path)[0] or "application/octet-stream"

    # The image is sent as multipart/form-data
    files = {"file": (os.path.basename(image_path), image_data, mime_type)}
    response = upload("/ib/v1/files", files)
    print("Received file upload response: {}".format(response.text))
    return response.json()["fileReferenceId"]


def create_market_commentary_with_title_image_payload(
    chatbot_uuid, room_id, file_reference_id
):
    market_commentary_element = {
        "contentType": "MARKET COMMENTARY",
        "title": "Out of the Box: Looking Out and Lookout",
        # Reference the uploaded image by the fileReferenceId returned from
        # /ib/v1/files
        "titleImage": {"fileReferenceId": file_reference_id},
        "body": {
            "blocks": [
                {
                    "type": "Paragraph",
                    "tokens": [
                        {
                            "type": "Text",
                            "text": "The markets currently are flummoxed, ",
                            "attributes": {"strong": True},
                        },
                        {
                            "type": "Text",
                            "text": "in my opinion, and caution is advised.",
                        },
                    ],
                }
            ]
        },
        "metadata": {
            "instruments": [{"figi": "BBG000B9XRY4"}, {"figi": "BBG000N9MNX3"}]
        },
    }
    return {
        "chatbotId": {"uuid": chatbot_uuid},
        "recipient": {"roomId": room_id},
        "chatMessage": [
            {
                "messageElements": [
                    {
                        "contentType": "TEXT",
                        "text": "This is a market commentary with a title image:\n",
                    },
                    market_commentary_element,
                ]
            }
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Upload an image and post it as the title image of a market commentary."
    )
    parser.add_argument(
        "--chatbot-uuid", type=int, required=True, help="UUID of your chatbot"
    )
    parser.add_argument(
        "--room-id",
        required=True,
        help='ID of the room to post to. Press Ctrl+Shift+R on an IB room to copy its ID '
        '(ex: "PCHAT-0x100000234567")',
    )
    parser.add_argument(
        "--image-path",
        default=DEFAULT_IMAGE_PATH,
        help="Path to the title image (jpg, jpeg, png, gif, or webp). "
        "Defaults to a sample Bloomberg logo",
    )
    args = parser.parse_args()

    try:
        file_reference_id = upload_title_image(args.image_path)
        post("/ib/v1/chatbot", create_market_commentary_with_title_image_payload(
            args.chatbot_uuid, args.room_id, file_reference_id
        ))
    except Exception as e:
        print(f"Exception was thrown: {e=}")
