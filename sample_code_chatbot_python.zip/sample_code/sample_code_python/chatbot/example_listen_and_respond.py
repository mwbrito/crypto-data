import argparse
import json
import random
import time

from http_client import get, post
from requests.exceptions import ChunkedEncodingError


def make_payload(bot_uuid, room_id, reply_to_id):
    payload = {
        "chatbotId": {
            "uuid": bot_uuid,
        },
        "recipient": {
            "roomId": room_id,
        },
        "chatMessage": [
            {
                "messageElements": [
                    {"contentType": "TEXT", "text": "Message posted successfully!"}
                ],
            }
        ],
    }
    if reply_to_id:
        payload["chatMessage"][0]["replyToId"] = reply_to_id
    return payload


def is_bot_mentioned(bot_uuid, loaded_msg):
    # check if enrichments contain entity_person of the chatbot
    # this means that chatbot was mentioned in the message
    is_bot_at_mentioned = False
    for enrichment in loaded_msg["enrichments"]:
        if enrichment.get("@type", "") == "entity_person":
            if enrichment.get("instrument", {}).get("uuid") == bot_uuid:
                is_bot_at_mentioned = True
                break
    return is_bot_at_mentioned


def post_payload(path, payload):
    try:
        post(path, payload)
        print(f"Payload: {payload}")
    except Exception as e:
        print(f"Exception received when posting: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Listen on a stream and reply when the chatbot is mentioned."
    )
    parser.add_argument(
        "--chatbot-uuid", type=int, required=True, help="UUID of your chatbot"
    )
    parser.add_argument(
        "--stream-id", required=True, help="ID of the stream your chatbot subscribes to"
    )
    parser.add_argument(
        "--room-id",
        required=True,
        help='Room to limit listening to. Press Ctrl+Shift+R on an IB room to copy its ID '
        '(ex: "PCHAT-0x100000234567")',
    )
    parser.add_argument(
        "--enable-reply-to",
        action="store_true",
        help="Use the Reply-to feature in responses (otherwise reply with a plain message)",
    )
    args = parser.parse_args()

    max_backoff_second = 2**4  # You can set it to any value that fits your workflow
    backoff_second = 1
    while True:
        try:
            response = get("/ib/v1/streams/" + args.stream_id, stream=True)
            lines = response.iter_lines()

            print("Start listening to the stream...")
            backoff_second = 1  # reset backoff time

            for line in lines:
                if not line:  # empty bytestring
                    continue
                loaded_msg = json.loads(line)

                # only print and respond to stream messages from the test chat
                if "roomId" in loaded_msg and loaded_msg["roomId"] != args.room_id:
                    continue

                print(f"Received message from stream: {loaded_msg}")

                if not loaded_msg:  # i.e. heartbeat
                    continue

                if is_bot_mentioned(
                    args.chatbot_uuid, loaded_msg
                ):  # check only required for Base-Feed streams which receive all chat messages
                    room_id = loaded_msg["roomId"]
                    reply_to_id = loaded_msg["eventId"] if args.enable_reply_to else None
                    payload = make_payload(args.chatbot_uuid, room_id, reply_to_id)
                    post_payload("/ib/v1/chatbot", payload)  # dummy response

        except ChunkedEncodingError as e:
            print(f"ChunkedEncodingError happened {e}")
        except Exception as e:
            print(f"Exception happened {e}")

        # Exponential backoff: the sleep time is capped by max_backoff_second
        sleep_time = backoff_second + random.uniform(0, 0.5)
        print(f"Trying again in {sleep_time} seconds...")
        time.sleep(sleep_time)
        backoff_second = min(backoff_second * 2, max_backoff_second)
