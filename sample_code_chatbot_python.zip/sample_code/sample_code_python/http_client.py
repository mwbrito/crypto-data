"""
Copyright 2017 Bloomberg L.P. All rights reserved.

Use governed by applicable Bloomberg Terminal agreement.

"""

import binascii
import json
import os
import time
import uuid

import jwt
import requests
from functools import wraps

# Credentials are read from environment variables. Export them before running:
#   export IBAPI_CLIENT_ID=... IBAPI_CLIENT_SECRET=...
# Keep your real credentials private; do not commit or share them.


def _require_env(name):
    """Return a required environment variable, or raise a clear error if unset."""
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(
            f"Missing required environment variable {name!r}. "
            "Set IBAPI_CLIENT_ID and IBAPI_CLIENT_SECRET in your environment "
            "(see README.md for setup instructions)."
        )
    return value


# The API endpoint defaults to production. It can be overridden with the
# IBAPI_API_URL environment variable (e.g. to point at a Bloomberg-internal test
# environment); leaving it unset keeps the normal production behavior. The JWT
# `host` claim is derived from this endpoint, so requests are signed for whichever
# host is targeted.
endpoint = os.environ.get("IBAPI_API_URL", "https://api.bloomberg.com")
client_id = _require_env("IBAPI_CLIENT_ID")
client_secret = _require_env("IBAPI_CLIENT_SECRET")


def generate_jwt(uri, path, method):
    """
    Generates a JWT from the URL and ID, and secret.
    See authentication_documentation/jwt.md for details
    """

    # Get the current time in seconds since the epoch
    current_time = int(round(time.time()))

    # This is json encoded, then stored in the body of the JWT
    body = {
        "iss": client_id,
        "exp": int(current_time + 300),  # expire time, 5 minutes from now
        # We subtract 60 seconds from these values in case our clock is
        # not well synchronized
        "nbf": int(current_time - 60),  # not-before time
        "iat": int(current_time - 60),  # issued-at time
        "region": "default",  # 'default' is the only allowed value for region
        "method": method,
        "path": path,
        "host": uri,
        # nonce, this could be any random string
        "jti": str(uuid.uuid4()),
    }

    # Encode the JWT using the body, and hash it with the client secret.
    # Use the HS256 HMAC algorithm. HS384 or HS512 could also be used.
    # If you are re-implementing this in some other language other than python
    # use your languages JWT function, or find a popular library. For example
    # node-jsonwebtoken for node.js, java-jwt for java, or jwt-dotnet for .NET
    return jwt.encode(
        body,
        # Convert the hex client_secret to binary data
        binascii.unhexlify(client_secret),
        algorithm="HS256",
    )


def generate_url(uri, path, method):
    """
    This function generates the JWT, and appends it onto the URL with
    a jwt= query parameter.
    """
    return uri + path + "?jwt=" + generate_jwt(uri, path, method)


# Maximum number of retries for 503 Service Unavailable errors
MAX_503_RETRIES = 4


def make_retryable(f):
    @wraps(f)
    def _f(*args, **kwargs):
        for retry in range(MAX_503_RETRIES):
            response = f(*args, **kwargs)
            if response.status_code == 503:
                print(
                    f"Server temporarily unavailable (503). Retry {retry+1}/{MAX_503_RETRIES}..."
                )
                time.sleep(2 ** retry)  # Exponential backoff: 1s, 2s, 4s
                continue
            return response
        raise Exception(
            f"Server unavailable after {MAX_503_RETRIES} retries (503)"
        )
    return _f


class retryable:
    get = make_retryable(requests.get)
    post = make_retryable(requests.post)


def get(path, stream=False):
    uri_with_jwt = generate_url(endpoint, path, "GET")

    response = retryable.get(uri_with_jwt, stream=stream)
    if response.status_code not in range(200, 300):
        print("Response body: {}".format(response.text))
        raise Exception(
            "Get returned error status: {} - {}".format(
                response.status_code, response.reason
            )
        )
    return response


def post(path, json_payload):
    uri_with_jwt = generate_url(endpoint, path, "POST")

    # set the content type header when posting data. This ensures
    # that the server knows to expect JSON encoded data
    headers = {"Content-type": "application/json"}
    response = retryable.post(
        uri_with_jwt, data=json.dumps(json_payload), headers=headers
    )
    if response.status_code not in range(200, 300):
        print("Response body: {}".format(response.text))
        raise Exception(
            "Post returned error status: {} - {}".format(
                response.status_code, response.reason
            )
        )
    print("Post success")
    return response


def upload(path, files):
    uri_with_jwt = generate_url(endpoint, path, "POST")

    # Do not set a Content-type header here: requests builds the
    # multipart/form-data header (including its boundary) from `files`
    response = retryable.post(uri_with_jwt, files=files)
    if response.status_code not in range(200, 300):
        print("Response body: {}".format(response.text))
        raise Exception(
            "Upload returned error status: {} - {}".format(
                response.status_code, response.reason
            )
        )
    print("Upload success")
    return response
